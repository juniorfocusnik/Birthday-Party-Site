This is a font property of LJ-Design Studios, designed for outdoor commercial use. 

More Fonts in: http://www.fontspace.com/lj-design-studios 
Blog Design: http://lj-Img.blogspot.com 
Facebook: http://www.facebook.com/LJIMGS 

Designed in 2014 by Luis Jaramillo. copyright